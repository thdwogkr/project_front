import React from 'react';
import Users from './Users';

function App() {
  return <Users />;
}

export default App;